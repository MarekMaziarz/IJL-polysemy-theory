Copyright 2023 by F. Bond, M. Maziarz, T. Piotrowski, and Ewa Rudnicka.
License: CC-BY, available at https://creativecommons.org/licenses/by/4.0/.

This dataset comprises:

    Four files named "IJL-simi-{dictionary}-{POS}-bootstrap2d_perc_sim_dissim_LLM2_dist2.txt." Each file presents the bootstrap results obtained from comparing the distances between close senses with distances between distant senses. These measurements are based on unweighted polysemy networks constructed by various polysemy algorithms.
    
dictionary in ['Lexico', 'Merriam']
POS in ['n', 'v']
