Copyright 2023 by F. Bond, M. Maziarz, T. Piotrowski, and Ewa Rudnicka.
License: CC-BY, available at https://creativecommons.org/licenses/by/4.0/.

This dataset comprises:

    Four files named "IJL-simi-{dictionary}-{POS}-bootstrap2ddissim_LLM2_dist2.txt," each presenting the results obtained from measuring the average distance between distant senses across 500 bootstrap resamplings.

dictionary in ['Lexico', 'Merriam']
POS in ['n', 'v']
