Copyright 2023 by F. Bond, M. Maziarz, T. Piotrowski, and Ewa Rudnicka.
License: CC-BY, available at https://creativecommons.org/licenses/by/4.0/.

This dataset comprises:

    Four files named "IJL-results-{dictionary}-{POS}-steps-transposed3-POSsplit-LLM.txt," each detailing the average sense similarity measured within polysemy networks. Each step represents the step of a sense linking algorithm.

dictionary in ['Lexico', 'Merriam']
POS in ['n', 'v']
